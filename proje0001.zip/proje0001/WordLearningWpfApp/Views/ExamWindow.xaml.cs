using System.Windows;
using WordLearningWpfApp.ViewModels;

namespace WordLearningWpfApp.Views
{
    public partial class ExamWindow : BaseWindow
    {
        public ExamWindow(ExamViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
} 