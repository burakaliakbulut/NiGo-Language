using System;
using System.Windows;
using System.Windows.Controls;
using WordLearningWpfApp.Services;
using WordLearningWpfApp.ViewModels;

namespace WordLearningWpfApp.Views
{
    public partial class LoginWindow : BaseWindow
    {
        private readonly IAuthService _authService;
        private readonly INavigationService _navigationService;
        private readonly INotificationService _notificationService;
        private readonly LoginViewModel _viewModel;

        public LoginWindow(IAuthService authService, INavigationService navigationService, INotificationService notificationService)
        {
            InitializeComponent();
            _authService = authService;
            _navigationService = navigationService;
            _notificationService = notificationService;
            _viewModel = new LoginViewModel(_authService, _navigationService, _notificationService);
            DataContext = _viewModel;
        }

        private void ShowLoadingIndicator()
        {
            if (LoadingProgressBar != null)
            {
                LoadingProgressBar.Visibility = Visibility.Visible;
            }
        }

        private void HideLoadingIndicator()
        {
            if (LoadingProgressBar != null)
            {
                LoadingProgressBar.Visibility = Visibility.Collapsed;
            }
        }

        private void ShowError(string message)
        {
            if (ErrorTextBlock != null)
            {
                ErrorTextBlock.Text = message;
                ErrorTextBlock.Visibility = Visibility.Visible;
            }
        }

        private void HideError()
        {
            if (ErrorTextBlock != null)
            {
                ErrorTextBlock.Text = string.Empty;
                ErrorTextBlock.Visibility = Visibility.Collapsed;
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmailTextBox != null && PasswordBox != null)
            {
                _viewModel.Email = EmailTextBox.Text;
                _viewModel.Password = PasswordBox.Password;
                _viewModel.LoginCommand.Execute(null);
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.RegisterCommand.Execute(null);
        }

        private void ForgotPasswordButton_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.ForgotPasswordCommand.Execute(null);
        }

        private void TogglePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            if (PasswordBox.Visibility == Visibility.Visible)
            {
                PasswordBox.Visibility = Visibility.Collapsed;
                PasswordTextBox.Visibility = Visibility.Visible;
                PasswordTextBox.Text = PasswordBox.Password;
                TogglePasswordButton.Content = new PackIcon { Kind = PackIconKind.EyeOff };
            }
            else
            {
                PasswordBox.Visibility = Visibility.Visible;
                PasswordTextBox.Visibility = Visibility.Collapsed;
                PasswordBox.Password = PasswordTextBox.Text;
                TogglePasswordButton.Content = new PackIcon { Kind = PackIconKind.Eye };
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginViewModel vm && sender is PasswordBox pb)
            {
                vm.Password = pb.Password;
            }
        }
    }
} 