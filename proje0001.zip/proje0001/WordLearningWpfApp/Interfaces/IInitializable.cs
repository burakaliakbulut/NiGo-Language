using System.Threading.Tasks; namespace WordLearningWpfApp.Interfaces { public interface IInitializable { Task InitializeAsync(); } }
