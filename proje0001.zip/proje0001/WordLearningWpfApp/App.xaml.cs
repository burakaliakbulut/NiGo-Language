using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using WordLearningWpfApp.Data;
using WordLearningWpfApp.Services;
using WordLearningWpfApp.ViewModels;
using WordLearningWpfApp.Views;

namespace WordLearningWpfApp
{
    public partial class App : Application
    {
        private IServiceProvider _serviceProvider;
        private IConfiguration _configuration;

        public App()
        {
            _configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            var services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Configuration
            services.AddSingleton(_configuration);

            // Database
            services.AddSingleton<MongoDbContext>();

            // Frame for NavigationService
            services.AddSingleton(new Frame());

            // Services
            services.AddSingleton<IAuthService, AuthService>();
            services.AddSingleton<IWordService, WordService>();
            services.AddSingleton<IExamService, ExamService>();
            services.AddSingleton<IStatisticsService, StatisticsService>();
            services.AddSingleton<IUserService, UserService>();
            services.AddSingleton<IAdminService, AdminService>();
            services.AddSingleton<INotificationService, NotificationService>();
            services.AddSingleton<INavigationService, NavigationService>();

            // ViewModels
            services.AddTransient<LoginViewModel>();
            services.AddTransient<RegisterViewModel>();
            services.AddTransient<MainViewModel>();
            services.AddTransient<WordListViewModel>();
            services.AddTransient<DictionaryViewModel>();
            services.AddTransient<DictionaryWindow>();
            services.AddTransient<StatisticsViewModel>();
            services.AddTransient<StatisticsWindow>();
            services.AddTransient<ExamViewModel>();
            services.AddTransient<DailyWordsViewModel>();
            services.AddTransient<ProgressViewModel>();
            services.AddTransient<WordStatsViewModel>();
            services.AddTransient<AddWordViewModel>();
            services.AddTransient<EditWordViewModel>();
            services.AddTransient<ForgotPasswordViewModel>();
            services.AddTransient<SettingsViewModel>();
            // Windows
            services.AddTransient<LoginWindow>();
            services.AddTransient<RegisterWindow>();
            services.AddTransient<MainWindow>();
            services.AddTransient<WordListWindow>();
            services.AddTransient<AddWordWindow>();
            services.AddTransient<EditWordWindow>();
            services.AddTransient<DailyWordsWindow>();
            services.AddTransient<ExamWindow>();
            services.AddTransient<ForgotPasswordWindow>();
            services.AddTransient<SettingsWindow>();
            services.AddTransient<ProgressWindow>();
            services.AddTransient<WordStatsWindow>();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            try
            {
                // Initialize services
                var dbContext = _serviceProvider.GetRequiredService<MongoDbContext>();
                dbContext.InitializeAsync().Wait();

                // Set up global exception handling
                AppDomain.CurrentDomain.UnhandledException += (s, args) =>
                {
                    var exception = args.ExceptionObject as Exception;
                    MessageBox.Show(
                        $"An unhandled exception occurred: {exception?.Message}",
                        "Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error
                    );
                };

                // Set up WPF exception handling
                DispatcherUnhandledException += (s, args) =>
                {
                    MessageBox.Show(
                        $"An unhandled exception occurred: {args.Exception.Message}",
                        "Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error
                    );
                    args.Handled = true;
                };

                var mainWindow = _serviceProvider.GetRequiredService<LoginWindow>();
                mainWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Failed to start application: {ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                Shutdown();
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);

            if (_serviceProvider is IDisposable disposable)
            {
                disposable.Dispose();
            }
        }
    }
} 