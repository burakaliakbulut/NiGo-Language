using System.Threading.Tasks;

namespace WordLearningWpfApp.Services
{
    public interface INavigationService
    {
        void NavigateTo(string pageName);
        void NavigateTo(object page);
        void GoBack();
        void GoForward();
        bool CanGoBack { get; }
        bool CanGoForward { get; }
        Task NavigateToLoginAsync();
        Task NavigateToRegisterAsync();
        Task NavigateToMainAsync();
        Task NavigateToWordListAsync();
        Task NavigateToExamAsync();
        Task NavigateToProgressAsync();
        Task NavigateToSettingsAsync();
        Task NavigateToWordStatsAsync();
        Task NavigateToForgotPasswordAsync();
        Task NavigateBackAsync();
        Task NavigateToDailyWordsAsync();
        Task NavigateToStatisticsAsync();
        Task NavigateToDictionaryAsync();
        Task NavigateToMain();
        Task NavigateToAsync(string pageName);
        Task NavigateToAddWordAsync();
        Task NavigateToEditWordAsync(string wordId);
        Task NavigateToLogin();
    }
} 