using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using MongoDB.Driver;
using WordLearningWpfApp.Data;
using WordLearningWpfApp.Models;
using Microsoft.Extensions.Logging;

namespace WordLearningWpfApp.Services
{
    public class WordService : IWordService, IService
    {
        private readonly IMongoCollection<Word> _words;
        private readonly IMongoCollection<UserWordProgress> _userWordProgress;
        private readonly IMongoCollection<WordDifficultyLevel> _difficultyLevels;
        private readonly IMongoCollection<WordProgress> _wordProgress;
        private readonly IMongoCollection<WordSample> _samples;
        private bool _disposed;
        private readonly ILogger<WordService> _logger;

        public WordService(MongoDbContext dbContext, ILogger<WordService> logger)
        {
            _words = dbContext.Words ?? throw new ArgumentNullException(nameof(dbContext.Words));
            _userWordProgress = dbContext.GetCollection<UserWordProgress>(MongoDbContext.UserWordProgressCollection) 
                ?? throw new ArgumentNullException(nameof(MongoDbContext.UserWordProgressCollection));
            _difficultyLevels = dbContext.GetCollection<WordDifficultyLevel>(MongoDbContext.WordDifficultyLevelsCollection)
                ?? throw new ArgumentNullException(nameof(MongoDbContext.WordDifficultyLevelsCollection));
            _wordProgress = dbContext.WordProgress ?? throw new ArgumentNullException(nameof(dbContext.WordProgress));
            _samples = dbContext.GetCollection<WordSample>(MongoDbContext.WordSamplesCollection)
                ?? throw new ArgumentNullException(nameof(MongoDbContext.WordSamplesCollection));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task InitializeAsync()
        {
            try
            {
                _logger.LogInformation("Initializing WordService...");

                // Create indexes if they don't exist
                var wordIndexKeys = Builders<Word>.IndexKeys
                    .Ascending(w => w.UserId)
                    .Ascending(w => w.Category)
                    .Ascending(w => w.Difficulty);

                var wordProgressIndexKeys = Builders<WordProgress>.IndexKeys
                    .Ascending(wp => wp.UserId)
                    .Ascending(wp => wp.WordId);

                var userWordProgressIndexKeys = Builders<UserWordProgress>.IndexKeys
                    .Ascending(uwp => uwp.UserId)
                    .Ascending(uwp => uwp.WordId);

                await _words.Indexes.CreateOneAsync(new CreateIndexModel<Word>(wordIndexKeys));
                await _wordProgress.Indexes.CreateOneAsync(new CreateIndexModel<WordProgress>(wordProgressIndexKeys));
                await _userWordProgress.Indexes.CreateOneAsync(new CreateIndexModel<UserWordProgress>(userWordProgressIndexKeys));

                _logger.LogInformation("WordService initialization completed successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing WordService");
                throw new ServiceInitializationException("Failed to initialize WordService", ex);
            }
        }

        public async Task CleanupAsync()
        {
            try
            {
                _logger.LogInformation("Cleaning up WordService...");
                // Perform any necessary cleanup
                await Task.CompletedTask;
                _logger.LogInformation("WordService cleanup completed successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during WordService cleanup");
                throw new ServiceException("Failed to cleanup WordService", ex);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources
                    _logger.LogInformation("Disposing WordService resources");
                }
                _disposed = true;
            }
        }

        public async Task<Word> GetWordByIdAsync(string wordId)
        {
            try
            {
                if (string.IsNullOrEmpty(wordId))
                    throw new ArgumentException("Word ID cannot be null or empty", nameof(wordId));

                var filter = Builders<Word>.Filter.Eq(w => w.Id, wordId);
                var word = await _words.Find(filter).FirstOrDefaultAsync();
                
                if (word == null)
                    _logger.LogWarning("Word not found with ID: {WordId}", wordId);
                
                return word;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving word with ID: {WordId}", wordId);
                throw new ServiceException($"Failed to retrieve word with ID: {wordId}", ex);
            }
        }

        public async Task<IEnumerable<Word>> GetAllWordsAsync()
        {
            return await _words.Find(_ => true).ToListAsync();
        }

        public async Task<IEnumerable<Word>> GetWordsByCategoryAsync(string category)
        {
            var filter = Builders<Word>.Filter.Eq(w => w.Category, category);
            return await _words.Find(filter).ToListAsync();
        }

        public async Task<IEnumerable<Word>> GetWordsByUserIdAsync(string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

                var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
                return await _words.Find(filter).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving words for user: {UserId}", userId);
                throw new ServiceException($"Failed to retrieve words for user: {userId}", ex);
            }
        }

        public async Task<List<Word>> GetWordsByDifficultyAsync(string userId, WordDifficulty difficulty)
        {
            var filter = Builders<Word>.Filter.And(
                Builders<Word>.Filter.Eq(w => w.UserId, userId),
                Builders<Word>.Filter.Eq(w => w.Difficulty, difficulty)
            );
            return await _words.Find(filter).ToListAsync();
        }

        public async Task<List<Word>> GetWordsByTagsAsync(string userId, List<string> tags)
        {
            var filter = Builders<Word>.Filter.And(
                Builders<Word>.Filter.Eq(w => w.UserId, userId),
                Builders<Word>.Filter.All(w => w.Tags, tags)
            );
            return await _words.Find(filter).ToListAsync();
        }

        public async Task<Word> CreateWordAsync(Word word)
        {
            try
            {
                if (word == null)
                    throw new ArgumentNullException(nameof(word));

                word.CreatedAt = DateTime.UtcNow;
                word.UpdatedAt = DateTime.UtcNow;
                word.IsActive = true;

                await _words.InsertOneAsync(word);
                _logger.LogInformation("Created new word with ID: {WordId}", word.Id);
                return word;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating word");
                throw new ServiceException("Failed to create word", ex);
            }
        }

        public async Task<Word> UpdateWordAsync(Word word)
        {
            try
            {
                if (word == null)
                    throw new ArgumentNullException(nameof(word));

                word.UpdatedAt = DateTime.UtcNow;
                var filter = Builders<Word>.Filter.Eq(w => w.Id, word.Id);
                await _words.ReplaceOneAsync(filter, word);
                _logger.LogInformation("Updated word with ID: {WordId}", word.Id);
                return word;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating word with ID: {WordId}", word?.Id);
                throw new ServiceException($"Failed to update word with ID: {word?.Id}", ex);
            }
        }

        public async Task<bool> DeleteWordAsync(string wordId)
        {
            try
            {
                if (string.IsNullOrEmpty(wordId))
                    throw new ArgumentException("Word ID cannot be null or empty", nameof(wordId));

                var filter = Builders<Word>.Filter.Eq(w => w.Id, wordId);
                var result = await _words.DeleteOneAsync(filter);
                var success = result.DeletedCount > 0;
                
                if (success)
                    _logger.LogInformation("Deleted word with ID: {WordId}", wordId);
                else
                    _logger.LogWarning("Word not found for deletion with ID: {WordId}", wordId);
                
                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting word with ID: {WordId}", wordId);
                throw new ServiceException($"Failed to delete word with ID: {wordId}", ex);
            }
        }

        public async Task<IEnumerable<Word>> GetDailyWordsAsync(string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

                var today = DateTime.UtcNow.Date;
                var learnedWords = await _userWordProgress
                    .Find(p => p.UserId == userId && p.SuccessCount >= 3)
                    .Project(p => p.WordId)
                    .ToListAsync();

                var filter = Builders<Word>.Filter.And(
                    Builders<Word>.Filter.Nin(w => w.Id, learnedWords),
                    Builders<Word>.Filter.Eq(w => w.IsActive, true),
                    Builders<Word>.Filter.Eq(w => w.UserId, userId)
                );

                var words = await _words.Find(filter)
                    .Limit(10) // Default to 10 words
                    .ToListAsync();

                _logger.LogInformation("Retrieved {Count} daily words for user: {UserId}", words.Count, userId);
                return words;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving daily words for user: {UserId}", userId);
                throw new ServiceException($"Failed to retrieve daily words for user: {userId}", ex);
            }
        }

        public async Task<List<Word>> GetWeakWordsAsync(string userId, int count = 10)
        {
            var progress = await _userWordProgress
                .Find(p => p.UserId == userId)
                .SortBy(p => p.SuccessRate)
                .Limit(count)
                .ToListAsync();

            var wordIds = progress.Select(p => p.WordId).ToList();
            return await _words.Find(w => wordIds.Contains(w.Id)).ToListAsync();
        }

        public async Task<List<Word>> GetStrongWordsAsync(string userId, int count = 10)
        {
            var progress = await _userWordProgress
                .Find(p => p.UserId == userId)
                .SortByDescending(p => p.SuccessRate)
                .Limit(count)
                .ToListAsync();

            var wordIds = progress.Select(p => p.WordId).ToList();
            return await _words.Find(w => wordIds.Contains(w.Id)).ToListAsync();
        }

        public async Task<IEnumerable<Word>> SearchWordsAsync(string userId, string searchTerm)
        {
            try
            {
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
                if (string.IsNullOrEmpty(searchTerm))
                    throw new ArgumentException("Search term cannot be null or empty", nameof(searchTerm));

                var filter = Builders<Word>.Filter.And(
                    Builders<Word>.Filter.Eq(w => w.UserId, userId),
                    Builders<Word>.Filter.Or(
                        Builders<Word>.Filter.Regex(w => w.English, new MongoDB.Bson.BsonRegularExpression(searchTerm, "i")),
                        Builders<Word>.Filter.Regex(w => w.Turkish, new MongoDB.Bson.BsonRegularExpression(searchTerm, "i")),
                        Builders<Word>.Filter.Regex(w => w.Example, new MongoDB.Bson.BsonRegularExpression(searchTerm, "i"))
                    )
                );
                var words = await _words.Find(filter).ToListAsync();
                _logger.LogInformation("Found {Count} words matching search term '{SearchTerm}' for user {UserId}", 
                    words.Count, searchTerm, userId);
                return words;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching words for user {UserId} with term '{SearchTerm}'", userId, searchTerm);
                throw new ServiceException($"Failed to search words for user {userId} with term '{searchTerm}'", ex);
            }
        }

        public async Task<Dictionary<string, int>> GetWordStatisticsAsync(string userId)
        {
            var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
            var words = await _words.Find(filter).ToListAsync();
            return words.GroupBy(w => w.Difficulty.ToString())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public async Task UpdateWordProgressAsync(string userId, string wordId, bool isCorrect)
        {
            var filter = Builders<WordProgress>.Filter.And(
                Builders<WordProgress>.Filter.Eq(wp => wp.UserId, userId),
                Builders<WordProgress>.Filter.Eq(wp => wp.WordId, wordId)
            );

            var progress = await _wordProgress.Find(filter).FirstOrDefaultAsync();
            progress ??= new WordProgress
                {
                    UserId = userId,
                    WordId = wordId,
                    Status = WordStatus.New,
                    CorrectAnswers = 0,
                    IncorrectAnswers = 0
                };

            if (isCorrect)
                progress.CorrectAnswers++;
            else
                progress.IncorrectAnswers++;

            progress.Status = CalculateWordStatus(progress);
            await _wordProgress.ReplaceOneAsync(filter, progress, new ReplaceOptions { IsUpsert = true });
        }

        private WordStatus CalculateWordStatus(WordProgress progress)
        {
            var totalAttempts = progress.CorrectAnswers + progress.IncorrectAnswers;
            if (totalAttempts == 0) return WordStatus.New;
            
            var successRate = (double)progress.CorrectAnswers / totalAttempts;
            return successRate switch
            {
                >= 0.8 => WordStatus.Mastered,
                >= 0.6 => WordStatus.Reviewing,
                _ => WordStatus.Learning
            };
        }

        public async Task<bool> DeactivateWordAsync(string wordId)
        {
            var update = Builders<Word>.Update
                .Set(w => w.IsActive, false)
                .Set(w => w.UpdatedAt, DateTime.UtcNow);

            var result = await _words.UpdateOneAsync(w => w.Id == wordId, update);
            return result.ModifiedCount > 0;
        }

        public async Task<bool> ActivateWordAsync(string wordId)
        {
            var update = Builders<Word>.Update
                .Set(w => w.IsActive, true)
                .Set(w => w.UpdatedAt, DateTime.UtcNow);

            var result = await _words.UpdateOneAsync(w => w.Id == wordId, update);
            return result.ModifiedCount > 0;
        }

        public async Task<List<Word>> GetWordsForReviewAsync(string userId)
        {
            var today = DateTime.UtcNow.Date;
            var progress = await _userWordProgress
                .Find(p => p.UserId == userId && p.NextReview <= today)
                .ToListAsync();

            var wordIds = progress.Select(p => p.WordId).ToList();
            return await _words.Find(w => wordIds.Contains(w.Id)).ToListAsync();
        }

        public async Task<UserWordProgress> GetLatestUserProgressAsync(string userId)
        {
            return await _userWordProgress
                .Find(p => p.UserId == userId)
                .SortByDescending(p => p.UpdatedAt)
                .FirstOrDefaultAsync();
        }

        public async Task<int> GetTodayLearnedWordCountAsync(string userId)
        {
            var today = DateTime.UtcNow.Date;
            var tomorrow = today.AddDays(1);

            var count = await _userWordProgress.CountDocumentsAsync(p =>
                p.UserId == userId &&
                p.UpdatedAt >= today &&
                p.UpdatedAt < tomorrow &&
                p.SuccessCount >= 1
            );

            return (int)count;
        }

        public async Task<bool> MarkWordAsLearnedAsync(string wordId, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(wordId))
                    throw new ArgumentException("Word ID cannot be null or empty", nameof(wordId));
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

                var progress = await _userWordProgress
                    .Find(p => p.UserId == userId && p.WordId == wordId)
                    .FirstOrDefaultAsync();

                progress ??= new UserWordProgress
                    {
                        UserId = userId,
                        WordId = wordId,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                progress.IsLearned = true;
                progress.UpdatedAt = DateTime.UtcNow;

                var options = new ReplaceOptions { IsUpsert = true };
                var result = await _userWordProgress.ReplaceOneAsync(
                    p => p.UserId == userId && p.WordId == wordId,
                    progress,
                    options
                );

                var success = result.ModifiedCount > 0 || result.UpsertedId != null;
                if (success)
                    _logger.LogInformation("Marked word {WordId} as learned for user {UserId}", wordId, userId);
                
                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking word {WordId} as learned for user {UserId}", wordId, userId);
                throw new ServiceException($"Failed to mark word {wordId} as learned for user {userId}", ex);
            }
        }

        public async Task<bool> MarkWordAsDifficultAsync(string wordId, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(wordId))
                    throw new ArgumentException("Word ID cannot be null or empty", nameof(wordId));
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

                var progress = await _userWordProgress
                    .Find(p => p.UserId == userId && p.WordId == wordId)
                    .FirstOrDefaultAsync();

                progress ??= new UserWordProgress
                    {
                        UserId = userId,
                        WordId = wordId,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                progress.LearningStage = LearningStage.Difficult;
                progress.UpdatedAt = DateTime.UtcNow;

                var options = new ReplaceOptions { IsUpsert = true };
                var result = await _userWordProgress.ReplaceOneAsync(
                    p => p.UserId == userId && p.WordId == wordId,
                    progress,
                    options
                );

                var success = result.ModifiedCount > 0 || result.UpsertedId != null;
                if (success)
                    _logger.LogInformation("Marked word {WordId} as difficult for user {UserId}", wordId, userId);
                
                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking word {WordId} as difficult for user {UserId}", wordId, userId);
                throw new ServiceException($"Failed to mark word {wordId} as difficult for user {userId}", ex);
            }
        }

        public async Task<IEnumerable<Word>> GetLearnedWordsAsync(string userId)
        {
            var progress = await _userWordProgress
                .Find(p => p.UserId == userId && p.IsLearned)
                .ToListAsync();

            var wordIds = progress.Select(p => p.WordId).ToList();
            return await _words.Find(w => wordIds.Contains(w.Id)).ToListAsync();
        }

        public async Task<IEnumerable<Word>> GetDifficultWordsAsync(string userId)
        {
            var progress = await _userWordProgress
                .Find(p => p.UserId == userId && p.LearningStage == LearningStage.Difficult)
                .ToListAsync();

            var wordIds = progress.Select(p => p.WordId).ToList();
            return await _words.Find(w => wordIds.Contains(w.Id)).ToListAsync();
        }

        public async Task<IEnumerable<string>> GetCategoriesAsync(string userId)
        {
            var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
            var categories = await _words.Distinct(w => w.Category, filter).ToListAsync();
            return categories.Where(c => !string.IsNullOrEmpty(c));
        }

        public async Task<List<UserWordProgress>> GetUserWordProgressAsync(string userId)
        {
            return await _userWordProgress.Find(p => p.UserId == userId).ToListAsync();
        }

        public async Task<IEnumerable<Word>> GetAllWordsAsync(string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId))
                    throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

                var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
                return await _words.Find(filter).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all words for user: {UserId}", userId);
                throw new ServiceException($"Failed to retrieve all words for user: {userId}", ex);
            }
        }

        public async Task<IEnumerable<string>> GetTagsAsync(string userId)
        {
            var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
            var tags = await _words.Distinct(w => w.Tags, filter).ToListAsync();
            return tags.Where(t => !string.IsNullOrWhiteSpace(t)).Distinct();
        }

        public async Task<IEnumerable<Word>> GetDictionaryWordsAsync(string userId)
        {
            // Dummy implementation
            return await Task.FromResult(new List<Word>());
        }

        public async Task<bool> AddWordToLearningAsync(string userId, string wordId)
        {
            // Dummy implementation
            return await Task.FromResult(true);
        }

        public async Task<IEnumerable<Word>> SearchDictionaryWordsAsync(string userId, string searchTerm)
        {
            // Dummy implementation
            return await Task.FromResult(new List<Word>());
        }

        public async Task<bool> AddWordAsync(string userId, Word word)
        {
            // Example implementation
            try
            {
                word.UserId = userId;
                await _words.InsertOneAsync(word);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> UpdateWordProgressAsync(string userId, string wordId, WordProgress progress)
        {
            // Dummy implementation
            return await Task.FromResult(true);
        }

        public async Task<List<Word>> GetWordsAsync(string userId, string? category = null)
        {
            var filter = Builders<Word>.Filter.Eq(w => w.UserId, userId);
            if (!string.IsNullOrEmpty(category))
            {
                filter &= Builders<Word>.Filter.Eq(w => w.Category, category);
            }
            return await _words.Find(filter).ToListAsync();
        }

        public async Task<bool> AddWordSampleAsync(string wordId, WordSample sample)
        {
            try
            {
                sample.WordId = wordId;
                await _samples.InsertOneAsync(sample);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteWordSampleAsync(string sampleId)
        {
            try
            {
                var result = await _samples.DeleteOneAsync(s => s.Id == sampleId);
                return result.DeletedCount > 0;
            }
            catch
            {
                return false;
            }
        }

        public async Task<List<WordSample>> GetWordSamplesAsync(string wordId)
        {
            return await _samples.Find(s => s.WordId == wordId).ToListAsync();
        }

        public async Task<bool> UpdateWordProgressAsync(string wordId, WordProgress progress)
        {
            try
            {
                var update = Builders<Word>.Update
                    .Set(w => w.LastReviewedAt, DateTime.UtcNow)
                    .Set(w => w.ReviewCount, progress.ReviewCount)
                    .Set(w => w.SuccessRate, progress.SuccessRate);

                var result = await _words.UpdateOneAsync(w => w.Id == wordId, update);
                return result.ModifiedCount > 0;
            }
            catch
            {
                return false;
            }
        }
    }
} 