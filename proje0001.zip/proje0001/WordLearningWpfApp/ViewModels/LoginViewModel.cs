using System;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using WordLearningWpfApp.Services;
using WordLearningWpfApp.Models;
using WordLearningWpfApp.Interfaces;

namespace WordLearningWpfApp.ViewModels
{
    public class LoginViewModel : ViewModelBase, IInitializable
    {
        private readonly IAuthService _authService;
        protected new readonly INavigationService _navigationService;
        protected new readonly INotificationService _notificationService;
        private string _email = string.Empty;
        private string _password = string.Empty;
        private bool _rememberMe;
        private bool _isLoading;
        private string _errorMessage = string.Empty;

        public LoginViewModel(
            IAuthService authService,
            INavigationService navigationService,
            INotificationService notificationService)
            : base(navigationService, notificationService)
        {
            _authService = authService ?? throw new ArgumentNullException(nameof(authService));
            _navigationService = navigationService ?? throw new ArgumentNullException(nameof(navigationService));

            LoginCommand = new RelayCommand<PasswordBox>(async passwordBox => await LoginAsync(passwordBox));
            RegisterCommand = new RelayCommand(async _ => await RegisterAsync());
            ForgotPasswordCommand = new RelayCommand(async _ => await ForgotPasswordAsync());
        }

        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
                ClearError();
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged(nameof(Password));
                ClearError();
            }
        }

        public bool RememberMe
        {
            get => _rememberMe;
            set
            {
                _rememberMe = value;
                OnPropertyChanged(nameof(RememberMe));
            }
        }

        public bool IsLoading
        {
            get => _isLoading;
            private set
            {
                _isLoading = value;
                OnPropertyChanged(nameof(IsLoading));
            }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            private set
            {
                _errorMessage = value;
                OnPropertyChanged(nameof(ErrorMessage));
            }
        }

        public ICommand LoginCommand { get; }
        public ICommand RegisterCommand { get; }
        public ICommand ForgotPasswordCommand { get; }

        public override async Task InitializeAsync()
        {
            try
            {
                if (_authService.IsAuthenticated)
                {
                    await _navigationService.NavigateToAsync("Main");
                }
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Initialization failed", ex.Message);
            }
        }

        private bool CanLogin()
        {
            return !string.IsNullOrWhiteSpace(Email) && 
                   !string.IsNullOrWhiteSpace(Password) && 
                   !IsLoading;
        }

        private async Task LoginAsync(PasswordBox passwordBox)
        {
            if (IsLoading) return;

            try
            {
                IsLoading = true;
                ErrorMessage = string.Empty;

                if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(passwordBox.Password))
                {
                    ErrorMessage = "Please enter both email and password.";
                    return;
                }

                var result = await _authService.LoginAsync(Email, passwordBox.Password);
                if (result)
                {
                    if (RememberMe)
                    {
                        await _authService.SaveCredentialsAsync(Email, Password);
                    }
                    await _navigationService.NavigateToAsync("Main");
                }
                else
                {
                    ErrorMessage = "Invalid email or password.";
                }
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Login failed", ex.Message);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task RegisterAsync()
        {
            try
            {
                await _navigationService.NavigateToAsync("Register");
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Navigation failed", ex.Message);
            }
        }

        private async Task ForgotPasswordAsync()
        {
            try
            {
                await _navigationService.NavigateToAsync("ForgotPassword");
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Navigation failed", ex.Message);
            }
        }

        private void ClearError()
        {
            ErrorMessage = string.Empty;
        }
    }
} 