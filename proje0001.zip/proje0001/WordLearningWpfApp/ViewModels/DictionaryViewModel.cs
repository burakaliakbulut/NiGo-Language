using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using WordLearningWpfApp.Models;
using WordLearningWpfApp.Services;
using WordLearningWpfApp.Interfaces;

namespace WordLearningWpfApp.ViewModels
{
    public class DictionaryViewModel : ViewModelBase, IInitializable
    {
        private readonly IWordService _wordService;
        private readonly IAuthService _authService;
        private string _searchText = string.Empty;
        private string _selectedCategory = "All";
        private Word? _selectedWord;
        private ObservableCollection<Word> _words;
        private ObservableCollection<string> _categories;
        private bool _isLoading;

        public DictionaryViewModel(
            IWordService wordService,
            IAuthService authService,
            INavigationService navigationService,
            INotificationService notificationService)
            : base(navigationService, notificationService)
        {
            _wordService = wordService;
            _authService = authService;
            _words = new ObservableCollection<Word>();
            _categories = new ObservableCollection<string>();

            SearchCommand = new RelayCommand<string>(ExecuteSearch);
            AddWordCommand = new RelayCommand(ExecuteAddWord);
            EditWordCommand = new RelayCommand<Word>(ExecuteEditWord);
            DeleteWordCommand = new RelayCommand<Word>(ExecuteDeleteWord);
            CategoryChangedCommand = new RelayCommand<string>(ExecuteCategoryChanged);

            LoadDataAsync();
        }

        public new async Task InitializeAsync()
        {
            await LoadDataAsync();
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged();
                ExecuteSearch(value);
            }
        }

        public string SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                _selectedCategory = value;
                OnPropertyChanged();
                ExecuteCategoryChanged(value);
            }
        }

        public Word? SelectedWord
        {
            get => _selectedWord;
            set
            {
                _selectedWord = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Word> Words
        {
            get => _words;
            set
            {
                _words = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<string> Categories
        {
            get => _categories;
            set
            {
                _categories = value;
                OnPropertyChanged();
            }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                _isLoading = value;
                OnPropertyChanged();
            }
        }

        public ICommand SearchCommand { get; }
        public ICommand AddWordCommand { get; }
        public ICommand EditWordCommand { get; }
        public ICommand DeleteWordCommand { get; }
        public ICommand CategoryChangedCommand { get; }

        private async void LoadDataAsync()
        {
            try
            {
                IsLoading = true;
                var currentUser = await _authService.GetCurrentUserAsync();
                if (currentUser == null) return;

                var words = await _wordService.GetWordsByUserIdAsync(currentUser.Id);
                var categories = await _wordService.GetCategoriesAsync(currentUser.Id);

                Words = new ObservableCollection<Word>(words);
                Categories = new ObservableCollection<string>(new[] { "All" }.Concat(categories));
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Error", ex.Message);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async void ExecuteSearch(string? searchText)
        {
            try
            {
                IsLoading = true;
                var currentUser = await _authService.GetCurrentUserAsync();
                if (currentUser == null) return;

                var words = await _wordService.GetWordsByUserIdAsync(currentUser.Id);
                var filteredWords = words.Where(w =>
                    (string.IsNullOrEmpty(searchText) || w.Text.Contains(searchText, StringComparison.OrdinalIgnoreCase) ||
                     w.Translation.Contains(searchText, StringComparison.OrdinalIgnoreCase)) &&
                    (SelectedCategory == "All" || w.Category == SelectedCategory));

                Words = new ObservableCollection<Word>(filteredWords);
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Error", ex.Message);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void ExecuteAddWord()
        {
            _navigationService.NavigateToAddWord();
        }

        private void ExecuteEditWord(Word? word)
        {
            if (word != null)
            {
                _navigationService.NavigateToEditWord(word);
            }
        }

        private async void ExecuteDeleteWord(Word? word)
        {
            if (word == null) return;

            var confirm = await _notificationService.ShowConfirmationAsync(
                "Delete Word",
                $"Are you sure you want to delete the word '{word.Text}'?");

            if (confirm)
            {
                try
                {
                    await _wordService.DeleteWordAsync(word.Id);
                    Words.Remove(word);
                    await _notificationService.ShowSuccessAsync("Success", "Word deleted successfully");
                }
                catch (Exception ex)
                {
                    await _notificationService.ShowErrorAsync("Error", ex.Message);
                }
            }
        }

        private async void ExecuteCategoryChanged(string? category)
        {
            if (category == null) return;

            try
            {
                IsLoading = true;
                var currentUser = await _authService.GetCurrentUserAsync();
                if (currentUser == null) return;

                var words = await _wordService.GetWordsByUserIdAsync(currentUser.Id);
                var filteredWords = category == "All"
                    ? words
                    : words.Where(w => w.Category == category);

                Words = new ObservableCollection<Word>(filteredWords);
            }
            catch (Exception ex)
            {
                await _notificationService.ShowErrorAsync("Error", ex.Message);
            }
            finally
            {
                IsLoading = false;
            }
        }
    }
} 