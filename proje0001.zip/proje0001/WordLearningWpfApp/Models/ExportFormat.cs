namespace WordLearningWpfApp.Models
{
    public enum ExportFormat
    {
        CSV,
        JSON,
        Excel,
        PDF
    }
} 