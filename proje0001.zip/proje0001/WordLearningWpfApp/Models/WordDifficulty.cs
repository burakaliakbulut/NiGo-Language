namespace WordLearningWpfApp.Models
{
    public enum WordDifficulty
    {
        Easy,
        Medium,
        Hard
    }
} 