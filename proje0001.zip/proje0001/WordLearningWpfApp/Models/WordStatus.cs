namespace WordLearningWpfApp.Models
{
    public enum WordStatus
    {
        New,
        Learning,
        Reviewing,
        Mastered,
        Learned,
        Difficult
    }
} 