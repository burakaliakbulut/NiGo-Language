namespace WordLearningWpfApp.Models
{
    public enum WordCategory
    {
        General,
        Business,
        Academic,
        DailyConversation,
        Technical,
        Travel,
        Food,
        Sports,
        Art,
        Science
    }
} 