namespace WordLearningWpfApp.Models
{
    public enum ImportFormat
    {
        CSV,
        Excel,
        JSON
    }
} 