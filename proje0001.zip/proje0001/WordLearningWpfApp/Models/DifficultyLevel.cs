namespace WordLearningWpfApp.Models
{
    public enum DifficultyLevel
    {
        Easy,
        Medium,
        Hard
    }
} 